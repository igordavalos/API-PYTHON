import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='unirigor',
    application_name='todo-list-serverless',
    app_uid='Yz0mWgRBXfFhWGz6L4',
    org_uid='605dcf45-bec6-4fa2-9623-9320c8b8d58b',
    deployment_uid='50edf0b0-7bc5-43e4-91fa-449ab897e4c4',
    service_name='serverless-rest-api',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='3.8.4',
    disable_frameworks_instrumentation=False
)
handler_wrapper_kwargs = {'function_name': 'serverless-rest-api-dev-list', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('todos/list.list')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
